#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <ESP8266WebServer.h>
#include "DHTesp.h"

#define DHT_PIN       16


//SSID and Password of your WiFi router
const char* ssid = "yourwifi_ssid";
const char* password = "your_password";

ESP8266WebServer server(80); //Server on port 80
DHTesp dht;


/***************************************************************
 * SETUP
 **************************************************************/
void setup(void){
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);
  
  WiFi.begin(ssid, password);     //Connect to your WiFi router
  Serial.println("");

  // Wait for connection
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  //If connection successful show IP address in serial monitor
  Serial.println("");
  Serial.print("Connected to ");
  Serial.println(ssid);
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());  //IP address assigned to your ESP
 
  server.on("/", handleRoot);      //Which routine to handle at root location

  server.begin();                  //Start server
  Serial.println("HTTP server started");

  pinMode(LED_BUILTIN, OUTPUT); 

  dht.setup(DHT_PIN, DHTesp::DHT22); // Connect DHT sensor to GPIO16
}
/***************************************************************
 * LOOP
 **************************************************************/
void loop(void){
  server.handleClient();          //Handle client requests

  float temperature = dht.getTemperature();

  if (temperature > 25) {
    digitalWrite(LED_BUILTIN, LOW);
  }
  else {
    digitalWrite(LED_BUILTIN, HIGH);    
  }
}


/***************************************************************
 * This function converts IPAddress struct to a String
 **************************************************************/
String IpAddress2String(const IPAddress& ipAddress)
{
  return String(ipAddress[0]) + String(".") +\
  String(ipAddress[1]) + String(".") +\
  String(ipAddress[2]) + String(".") +\
  String(ipAddress[3])  ;
}


/***************************************************************
 * This rutine is exicuted when you open its IP in browser
 **************************************************************/
 void handleRoot() {
  IPAddress ip_address = WiFi.localIP();
  String ip_str = IpAddress2String(ip_address);

  float humidity = dht.getHumidity();
  float temperature = dht.getTemperature();

  bool stateLedPin = digitalRead(LED_BUILTIN);

  String strLedPin = stateLedPin ? "LED: OFF" : "LED: ON";
  
  String strTemp, strHum;
  char tmp[10];
  char hum[10];
  
  dtostrf(temperature,1,2,tmp);
  strTemp = tmp;
  dtostrf(humidity,1,2,hum);
  strHum = hum;

  server.send(200, "text/plain", "Hello from esp8266!\n\rIP: " + ip_str + ".\n\rTemp: " + strTemp + ", Hum: " + strHum + "\n\r" + strLedPin);
}
